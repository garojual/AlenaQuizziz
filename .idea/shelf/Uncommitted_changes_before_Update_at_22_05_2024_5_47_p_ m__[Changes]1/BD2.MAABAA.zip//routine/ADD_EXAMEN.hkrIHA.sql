create PROCEDURE add_examen (
    p_id_examen                IN examen.id_examen%TYPE,
    p_tipo                     IN examen.tipo%TYPE,
    p_nombre_examen            IN examen.nombre_examen%TYPE,
    p_num_preguntas            IN examen.num_preguntas%TYPE,
    p_tiempo_inicio            IN examen.tiempo_inicio%TYPE,
    p_tiempo_fin               IN examen.tiempo_fin%TYPE,
    p_num_preguntas_aleatorias IN examen.num_preguntas_aleatorias%TYPE,
    p_descripcion              IN examen.descripcion%TYPE,
    p_num_preguntas_banco      IN examen.num_preguntas_banco%TYPE,
    p_docente_id_docente       IN examen.docente_id_docente%TYPE,
    p_estado                   IN examen.estado%TYPE
) IS
BEGIN
    INSERT INTO examen (
        id_examen,
        tipo,
        nombre_examen,
        num_preguntas,
        tiempo_inicio,
        tiempo_fin,
        num_preguntas_aleatorias,
        descripcion,
        num_preguntas_banco,
        docente_id_docente,
        estado
    ) VALUES (
                 p_id_examen,
                 p_tipo,
                 p_nombre_examen,
                 p_num_preguntas,
                 p_tiempo_inicio,
                 p_tiempo_fin,
                 p_num_preguntas_aleatorias,
                 p_descripcion,
                 p_num_preguntas_banco,
                 p_docente_id_docente,
                 p_estado
             );
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Error al crear el examen: ' || SQLERRM);
END add_examen;
/

