create PROCEDURE add_examen_alumno (
    p_id_examen_alumno IN examen_alumno.id_examen_alumno%TYPE,
    p_id_examen        IN examen_alumno.id_examen%TYPE,
    p_id_estudiante    IN examen_alumno.id_estudiante%TYPE,
    p_calificacion     IN examen_alumno.calificacion%TYPE DEFAULT NULL,
    p_tiempo_final     IN examen_alumno.tiempo_final%TYPE DEFAULT NULL,
    p_direccion_ip     IN examen_alumno.direccion_ip%TYPE DEFAULT NULL
) IS
BEGIN
    INSERT INTO examen_alumno (
        id_examen_alumno,
        id_examen,
        id_estudiante,
        calificacion,
        tiempo_final,
        direccion_ip
    ) VALUES (
                 p_id_examen_alumno,
                 p_id_examen,
                 p_id_estudiante,
                 p_calificacion,
                 p_tiempo_final,
                 p_direccion_ip
             );
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Error al crear la relación examen-alumno: ' || SQLERRM);
END add_examen_alumno;
/

