create PROCEDURE add_pregunta (
    p_id_pregunta          IN pregunta.id_pregunta%TYPE,
    p_tema_id_tema         IN pregunta.tema_id_tema%TYPE,
    p_tipo_pregunta        IN pregunta.tipo_pregunta%TYPE,
    p_is_publica           IN pregunta.is_publica%TYPE,
    p_enunciado            IN pregunta.enunciado%TYPE,
    p_id_pregunta_padre    IN pregunta.id_pregunta_padre%TYPE DEFAULT NULL,
    p_docente_id_docente   IN pregunta.docente_id_docente%TYPE,
    p_estado               IN pregunta.estado%TYPE
) IS
BEGIN
    INSERT INTO pregunta (
        id_pregunta,
        tema_id_tema,
        tipo_pregunta,
        is_publica,
        enunciado,
        id_pregunta_padre,
        docente_id_docente,
        estado
    ) VALUES (
                 p_id_pregunta,
                 p_tema_id_tema,
                 p_tipo_pregunta,
                 p_is_publica,
                 p_enunciado,
                 p_id_pregunta_padre,
                 p_docente_id_docente,
                 p_estado
             );
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
END add_pregunta;
/

