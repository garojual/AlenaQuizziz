create PROCEDURE asociar_respuesta_pregunta (
    p_respuesta_id_respuesta IN detalle_respuesta_pregunta.respuesta_id_respuesta%TYPE,
    p_pregunta_id_pregunta   IN detalle_respuesta_pregunta.pregunta_id_pregunta%TYPE
) IS
BEGIN
    INSERT INTO detalle_respuesta_pregunta (
        respuesta_id_respuesta,
        pregunta_id_pregunta
    ) VALUES (
                 p_respuesta_id_respuesta,
                 p_pregunta_id_pregunta
             );
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Error al asociar la respuesta a la pregunta: ' || SQLERRM);
END asociar_respuesta_pregunta;
/

