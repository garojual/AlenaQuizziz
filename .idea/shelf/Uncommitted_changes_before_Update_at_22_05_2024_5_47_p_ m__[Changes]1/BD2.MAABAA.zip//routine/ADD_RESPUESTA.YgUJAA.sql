create PROCEDURE add_respuesta (
    p_id_respuesta        IN respuesta.id_respuesta%TYPE,
    p_enunciado_respuesta IN respuesta.enunciado_respuesta%TYPE,
    p_respuesta_correcta  IN respuesta.respuesta_correcta%TYPE
) IS
BEGIN
    INSERT INTO respuesta (
        id_respuesta,
        enunciado_respuesta,
        respuesta_correcta
    ) VALUES (
                 p_id_respuesta,
                 p_enunciado_respuesta,
                 p_respuesta_correcta
             );
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Error al crear la respuesta: ' || SQLERRM);
END add_respuesta;
/

