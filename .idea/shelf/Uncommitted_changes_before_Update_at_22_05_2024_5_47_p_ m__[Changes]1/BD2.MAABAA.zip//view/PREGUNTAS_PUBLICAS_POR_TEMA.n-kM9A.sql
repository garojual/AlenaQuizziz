create view PREGUNTAS_PUBLICAS_POR_TEMA as
SELECT
    t.nombre_tema AS tema,
    p.id_pregunta AS id_pregunta,
    p.enunciado AS enunciado,
    p.tipo_pregunta AS tipo_pregunta
FROM pregunta p
         JOIN tema t ON p.tema_id_tema = t.id_tema
WHERE p.is_publica = 1
/

