create FUNCTION get_preguntas_por_tema(
    tema IN PREGUNTAS_PUBLICAS_POR_TEMA.NOMBRE_TEMA%TYPE
) RETURN SYS_REFCURSOR AS
    preguntas_cursor SYS_REFCURSOR;
BEGIN
    OPEN preguntas_cursor FOR
        SELECT ID_PREGUNTA, ENUNCIADO
        FROM preguntas_publicas_por_tema
        WHERE NOMBRE_TEMA = tema;

    RETURN preguntas_cursor;
END;
/

