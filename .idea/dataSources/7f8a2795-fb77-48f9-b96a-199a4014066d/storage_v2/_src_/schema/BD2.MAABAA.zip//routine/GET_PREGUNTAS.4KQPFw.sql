create FUNCTION get_preguntas(p_examen_id IN INTEGER) RETURN SYS_REFCURSOR IS
    v_cursor SYS_REFCURSOR;
BEGIN
    OPEN v_cursor FOR
        SELECT id_pregunta, enunciado
        FROM preguntas_examen pe
                 JOIN pregunta pr ON pe.pregunta_id_pregunta = pr.id_pregunta
        WHERE pe.examen_id_examen = p_examen_id;
    RETURN v_cursor;
END;
/

