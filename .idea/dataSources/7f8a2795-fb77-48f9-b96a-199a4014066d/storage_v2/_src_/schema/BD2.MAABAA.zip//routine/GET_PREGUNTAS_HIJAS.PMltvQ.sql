create FUNCTION get_preguntas_hijas (
    p_id_pregunta IN NUMBER
) RETURN SYS_REFCURSOR IS
    preguntas_cursor SYS_REFCURSOR;
BEGIN
    OPEN preguntas_cursor FOR
        SELECT ID_PREGUNTA,ENUNCIADO
        FROM pregunta
        WHERE id_pregunta_padre1 = p_id_pregunta;

    RETURN preguntas_cursor;
END;
/

