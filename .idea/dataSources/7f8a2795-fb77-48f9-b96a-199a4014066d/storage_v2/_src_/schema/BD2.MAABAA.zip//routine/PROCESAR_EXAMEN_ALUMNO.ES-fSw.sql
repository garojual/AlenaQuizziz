create PROCEDURE procesar_examen_alumno(
    p_id_examen IN examen.id_examen%TYPE
) IS
    CURSOR c_examen_alumno IS
        SELECT id_examen_alumno
        FROM examen_alumno
        WHERE id_examen = p_id_examen;
    v_id_examen_alumno examen_alumno.id_examen_alumno%TYPE;
BEGIN
    OPEN c_examen_alumno;
    LOOP

        FETCH c_examen_alumno INTO v_id_examen_alumno;
        EXIT WHEN c_examen_alumno%NOTFOUND;

        -- Depuración para verificar si está ingresando al bucle y el ID de examen alumno
        DBMS_OUTPUT.PUT_LINE('Ingresó al bucle para el ID de examen alumno: ' || v_id_examen_alumno);

        -- Llamar al procedimiento add_preguntas_examen_alumno para cada registro
        add_preguntas_examen_alumno(v_id_examen_alumno);
    END LOOP;
    CLOSE c_examen_alumno;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
END;
/

