create trigger ADD_PREGUNTAS_FALTANTES
    instead of update of ESTADO
    on EXAMEN
    for each row
    COMPOUND TRIGGER

    -- Declaración de variables a nivel de declaración
    TYPE examen_info_t IS RECORD (
                                     id_examen        EXAMEN.ID_EXAMEN%TYPE,
                                     num_preguntas    EXAMEN.NUM_PREGUNTAS%TYPE,
                                     id_tema          EXAMEN.TEMA_ID_TEMA%TYPE
                                 );

    v_examen_info examen_info_t;

BEFORE STATEMENT IS
BEGIN
    -- Inicialización de variables
    v_examen_info.id_examen := NULL;
    v_examen_info.num_preguntas := NULL;
    v_examen_info.id_tema := NULL;
END BEFORE STATEMENT;

    AFTER EACH ROW IS
    BEGIN
        -- Solo actualizar la información si el estado es 'finalizado'
        IF :NEW.ESTADO = 'finalizado' THEN
            v_examen_info.id_examen := :NEW.ID_EXAMEN;
            v_examen_info.num_preguntas := :NEW.NUM_PREGUNTAS;
            v_examen_info.id_tema := :NEW.TEMA_ID_TEMA;
        END IF;
    END AFTER EACH ROW;

    AFTER STATEMENT IS
    BEGIN
        IF v_examen_info.id_examen IS NOT NULL THEN
            DECLARE
                v_num_preguntas_actuales NUMBER;
                v_num_preguntas_faltantes NUMBER;
                v_random_pregunta PREGUNTA.ID_PREGUNTA%TYPE;
                v_is_padre NUMBER;
            BEGIN
                -- Contar el número de preguntas actuales asociadas al examen
                SELECT COUNT(*)
                INTO v_num_preguntas_actuales
                FROM preguntas_examen
                WHERE examen_id_examen = v_examen_info.id_examen;

                -- Calcular el número de preguntas faltantes
                v_num_preguntas_faltantes := v_examen_info.num_preguntas - v_num_preguntas_actuales;

                -- Insertar preguntas aleatorias si faltan preguntas
                WHILE v_num_preguntas_faltantes > 0 LOOP
                        BEGIN
                            -- Seleccionar una pregunta aleatoria que no esté ya asociada al examen y que corresponda al tema
                            SELECT ID_PREGUNTA
                            INTO v_random_pregunta
                            FROM (
                                     SELECT P.ID_PREGUNTA
                                     FROM PREGUNTA P
                                              LEFT JOIN PREGUNTAS_EXAMEN PE
                                                        ON P.ID_PREGUNTA = PE.PREGUNTA_ID_PREGUNTA
                                                            AND PE.EXAMEN_ID_EXAMEN = v_examen_info.id_examen
                                     WHERE P.TEMA_ID_TEMA = v_examen_info.id_tema
                                     ORDER BY DBMS_RANDOM.VALUE
                                 )
                            WHERE ROWNUM = 1;

                            -- Verificar si la pregunta es una pregunta padre
                            SELECT COUNT(*)
                            INTO v_is_padre
                            FROM pregunta
                            WHERE id_pregunta_padre1 = v_random_pregunta;

                            -- Verificar si es padre
                            IF v_is_padre > 0 THEN
                                -- Insertar la pregunta padre en preguntas_examen
                                INSERT INTO preguntas_examen (examen_id_examen, pregunta_id_pregunta, porcentaje)
                                VALUES (v_examen_info.id_examen, v_random_pregunta, 20);

                                -- Decrementar el número de preguntas faltantes
                                v_num_preguntas_faltantes := v_num_preguntas_faltantes - 1;

                                -- Insertar todas las subpreguntas en preguntas_examen
                                FOR subpregunta IN (
                                    SELECT id_pregunta
                                    FROM pregunta
                                    WHERE id_pregunta_padre1 = v_random_pregunta
                                    ) LOOP
                                        INSERT INTO preguntas_examen (examen_id_examen, pregunta_id_pregunta, porcentaje)
                                        VALUES (v_examen_info.id_examen, subpregunta.id_pregunta, 10);

                                        -- Decrementar el número de preguntas faltantes
                                        v_num_preguntas_faltantes := v_num_preguntas_faltantes - 1;
                                    END LOOP;
                            ELSE
                                -- Si no es padre, insertar la pregunta normalmente
                                INSERT INTO preguntas_examen (examen_id_examen, pregunta_id_pregunta, porcentaje)
                                VALUES (v_examen_info.id_examen, v_random_pregunta, 20);

                                -- Decrementar el número de preguntas faltantes
                                v_num_preguntas_faltantes := v_num_preguntas_faltantes - 1;
                            END IF;

                        EXCEPTION
                            WHEN NO_DATA_FOUND THEN
                                -- No hay más preguntas disponibles para seleccionar
                                EXIT;
                        END;
                    END LOOP;
            END;
        END IF;
    END AFTER STATEMENT;

    END ADD_PREGUNTAS_FALTANTES;
/

