create trigger ADD_PREGUNTAS_FALTANTES
    after update of ESTADO
    on EXAMEN
    for each row
    when (NEW.estado = 'finalizado')
DECLARE
    v_id_examen examen.id_examen%TYPE;
    v_num_preguntas_actuales NUMBER;
    v_num_preguntas_faltantes NUMBER;
    v_random_pregunta pregunta.id_pregunta%TYPE;
    v_num_subpreguntas NUMBER;
    v_num_preguntas_insertadas NUMBER := 0;
BEGIN
    -- Asignar el valor de :NEW.id_examen a una variable local
    v_id_examen := :NEW.id_examen;

    -- Contar el número de preguntas actuales asociadas al examen
    SELECT COUNT(*)
    INTO v_num_preguntas_actuales
    FROM preguntas_examen
    WHERE examen_id_examen = v_id_examen;

    -- Calcular el número de preguntas faltantes
    v_num_preguntas_faltantes := :NEW.num_preguntas - v_num_preguntas_actuales;

    -- Insertar preguntas aleatorias si faltan preguntas
    WHILE v_num_preguntas_faltantes > 0 LOOP
            BEGIN
                -- Seleccionar una pregunta aleatoria que no esté ya asociada al examen
                SELECT id_pregunta
                INTO v_random_pregunta
                FROM (
                         SELECT p.id_pregunta
                         FROM pregunta p
                                  LEFT JOIN preguntas_examen pe
                                            ON p.id_pregunta = pe.pregunta_id_pregunta AND pe.examen_id_examen = v_id_examen
                         WHERE pe.pregunta_id_pregunta IS NULL
                         ORDER BY DBMS_RANDOM.VALUE
                     )
                WHERE ROWNUM = 1;

                -- Verificar si la pregunta tiene subpreguntas
                SELECT COUNT(*)
                INTO v_num_subpreguntas
                FROM pregunta
                WHERE id_pregunta_padre1 = v_random_pregunta;

                -- Si el número total de preguntas es menor o igual al número de preguntas faltantes,
                -- insertar tanto la pregunta padre como todas sus subpreguntas en preguntas_examen
                IF v_num_subpreguntas + 1 <= v_num_preguntas_faltantes THEN
                    -- Insertar la pregunta padre en preguntas_examen
                    INSERT INTO preguntas_examen (examen_id_examen, pregunta_id_pregunta, porcentaje)
                    VALUES (v_id_examen, v_random_pregunta, 20);

                    -- Incrementar el número de preguntas insertadas
                    v_num_preguntas_insertadas := v_num_preguntas_insertadas + 1;

                    -- Insertar todas las subpreguntas en preguntas_examen
                    FOR subpregunta IN (
                        SELECT id_pregunta
                        FROM pregunta
                        WHERE id_pregunta_padre1 = v_random_pregunta
                        ) LOOP
                            INSERT INTO preguntas_examen (examen_id_examen, pregunta_id_pregunta, porcentaje)
                            VALUES (v_id_examen, subpregunta.id_pregunta, 10);

                            -- Incrementar el número de preguntas insertadas
                            v_num_preguntas_insertadas := v_num_preguntas_insertadas + 1;
                        END LOOP;
                ELSE
                    -- Si la pregunta no tiene subpreguntas o no hay suficientes preguntas faltantes,
                    -- insertarla directamente en preguntas_examen
                    INSERT INTO preguntas_examen (examen_id_examen, pregunta_id_pregunta, porcentaje)
                    VALUES (v_id_examen, v_random_pregunta, 20);

                    -- Incrementar el número de preguntas insertadas
                    v_num_preguntas_insertadas := v_num_preguntas_insertadas + 1;
                END IF;

                -- Disminuir el número de preguntas faltantes
                v_num_preguntas_faltantes := v_num_preguntas_faltantes - 1;
            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                    -- No hay más preguntas disponibles para seleccionar
                    EXIT;
            END;
        END LOOP;
END;
/

