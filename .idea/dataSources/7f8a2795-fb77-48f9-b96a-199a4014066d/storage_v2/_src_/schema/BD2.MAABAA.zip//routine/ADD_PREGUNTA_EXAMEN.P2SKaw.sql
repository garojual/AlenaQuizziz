create PROCEDURE add_pregunta_examen (
    p_examen_id_examen     IN preguntas_examen.examen_id_examen%TYPE,
    p_pregunta_id_pregunta IN preguntas_examen.pregunta_id_pregunta%TYPE,
    p_porcentaje           IN preguntas_examen.porcentaje%TYPE
) AS
BEGIN
    INSERT INTO preguntas_examen (examen_id_examen, pregunta_id_pregunta, porcentaje)
    VALUES (p_examen_id_examen, p_pregunta_id_pregunta, p_porcentaje);
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Error al agregar la pregunta al examen: ' || SQLERRM);
END;
/

