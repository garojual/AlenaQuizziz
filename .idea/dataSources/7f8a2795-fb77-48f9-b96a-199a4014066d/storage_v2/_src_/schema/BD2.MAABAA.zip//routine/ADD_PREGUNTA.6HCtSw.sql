create FUNCTION add_pregunta (
    p_tema_id_tema       IN pregunta.tema_id_tema%TYPE,
    p_id_pregunta_padre1 IN pregunta.id_pregunta_padre1%TYPE,
    p_tipo_pregunta      IN pregunta.tipo_pregunta%TYPE,
    p_is_publica         IN pregunta.is_publica%TYPE,
    p_enunciado          IN pregunta.enunciado%TYPE,
    p_docente_id_docente IN pregunta.docente_id_docente%TYPE,
    p_estado             IN pregunta.estado%TYPE
) return number IS
    v_id_pregunta INTEGER;
BEGIN
    SELECT MAX(ID_PREGUNTA)+1 INTO v_id_pregunta FROM PREGUNTA ;
    INSERT INTO pregunta (
        id_pregunta,
        tema_id_tema,
        id_pregunta_padre1,
        tipo_pregunta,
        is_publica,
        enunciado,
        docente_id_docente,
        estado
    ) VALUES (
                 v_id_pregunta,
                 p_tema_id_tema,
                 p_id_pregunta_padre1,
                 p_tipo_pregunta,
                 p_is_publica,
                 p_enunciado,
                 p_docente_id_docente,
                 p_estado
             );
    COMMIT;
    return v_id_pregunta;

END add_pregunta;
/

