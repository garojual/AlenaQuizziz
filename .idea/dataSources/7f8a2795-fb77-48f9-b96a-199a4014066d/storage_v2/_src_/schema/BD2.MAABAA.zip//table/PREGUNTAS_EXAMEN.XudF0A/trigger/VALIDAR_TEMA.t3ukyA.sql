create trigger VALIDAR_TEMA
    before insert
    on PREGUNTAS_EXAMEN
    for each row
DECLARE
    v_tema_examen INTEGER;
    v_tema_pregunta INTEGER;
BEGIN
    -- Obtener el tema del examen
    SELECT tema_id_tema INTO v_tema_examen
    FROM examen
    WHERE id_examen = :NEW.examen_id_examen;

    -- Obtener el tema de la pregunta
    SELECT tema_id_tema INTO v_tema_pregunta
    FROM pregunta
    WHERE id_pregunta = :NEW.pregunta_id_pregunta;

    -- Validar que los temas coincidan
    IF v_tema_examen != v_tema_pregunta THEN
        RAISE_APPLICATION_ERROR(-20001, 'La pregunta no corresponde al tema del examen.');
    END IF;
END;
/

