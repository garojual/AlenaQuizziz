create FUNCTION get_tipo (id IN NUMBER)
    RETURN VARCHAR IS
    tipo VARCHAR(100);
    BEGIN
        SELECT TIPO_PREGUNTA INTO tipo FROM PREGUNTA WHERE ID_PREGUNTA = id;
        RETURN  tipo;
    end;
/

