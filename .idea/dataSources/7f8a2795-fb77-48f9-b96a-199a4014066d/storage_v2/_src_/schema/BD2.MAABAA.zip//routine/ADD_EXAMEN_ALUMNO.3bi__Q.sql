create FUNCTION add_examen_alumno (
    p_id_examen     IN examen_alumno.id_examen%TYPE,
    p_id_estudiante IN examen_alumno.id_estudiante%TYPE,
    p_calificacion  IN examen_alumno.calificacion%TYPE DEFAULT NULL,
    p_tiempo_final  IN examen_alumno.tiempo_final%TYPE DEFAULT NULL,
    p_direccion_ip  IN examen_alumno.direccion_ip%TYPE DEFAULT NULL
) RETURN examen_alumno.id_examen_alumno%TYPE IS
    v_new_id_examen_alumno examen_alumno.id_examen_alumno%TYPE;
BEGIN
    -- Generar el nuevo ID basado en el máximo valor actual en la tabla
    SELECT NVL(MAX(id_examen_alumno), 0) + 1 INTO v_new_id_examen_alumno FROM examen_alumno;

    -- Insertar el nuevo registro en la tabla
    INSERT INTO examen_alumno (
        id_examen_alumno,
        id_examen,
        id_estudiante,
        calificacion,
        tiempo_final,
        direccion_ip
    ) VALUES (
                 v_new_id_examen_alumno,
                 p_id_examen,
                 p_id_estudiante,
                 p_calificacion,
                 TO_DATE(p_tiempo_final, 'YYYY-MM-DD HH24:MI'),
                 p_direccion_ip
             );

    COMMIT;

    -- Retornar el nuevo ID generado
    RETURN v_new_id_examen_alumno;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Error al crear la relación examen-alumno: ' || SQLERRM);
        RETURN NULL;
END add_examen_alumno;
/

