create trigger VERIFICAR_MODIFICACION_EXAMEN
    before insert or update or delete
    on PREGUNTAS_EXAMEN
    for each row
DECLARE
    v_estado_examen examen.estado%TYPE;
    v_examen_presentado_count INTEGER;
BEGIN
    -- Obtener el estado del examen relacionado
    SELECT estado INTO v_estado_examen
    FROM examen
    WHERE id_examen = :new.examen_id_examen;

    -- Verificar si el estado del examen permite la inserción de preguntas
    IF v_estado_examen = 'presentado' THEN
        RAISE_APPLICATION_ERROR(-20001, 'El examen ya fue presentado por un alumno');
        END IF;
END;
/

