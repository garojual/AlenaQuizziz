create procedure add_respuesta (
    p_enunciado_respuesta IN respuesta.enunciado_respuesta%TYPE,
    p_respuesta_correcta  IN respuesta.respuesta_correcta%TYPE,
    p_id_pregunta         IN respuesta.id_pregunta%TYPE
) is
    v_id_respuesta INTEGER;
BEGIN
    SELECT MAX(ID_RESPUESTA)+1 INTO v_id_respuesta FROM RESPUESTA ;
    INSERT INTO respuesta (
        id_respuesta,
        enunciado_respuesta,
        respuesta_correcta,
        id_pregunta
    ) VALUES (
                 v_id_respuesta,
                 p_enunciado_respuesta,
                 p_respuesta_correcta,
                 p_id_pregunta
             );
    COMMIT;
END add_respuesta;
/

