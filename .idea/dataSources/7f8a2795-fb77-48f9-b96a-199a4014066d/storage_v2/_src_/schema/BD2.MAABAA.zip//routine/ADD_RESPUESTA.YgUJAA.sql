create PROCEDURE add_respuesta (
    p_id_respuesta        IN respuesta.id_respuesta%TYPE,
    p_enunciado_respuesta IN respuesta.enunciado_respuesta%TYPE,
    p_respuesta_correcta  IN respuesta.respuesta_correcta%TYPE,
    p_id_pregunta         IN respuesta.id_pregunta%TYPE
) AS
BEGIN
    INSERT INTO respuesta (
        id_respuesta,
        enunciado_respuesta,
        respuesta_correcta,
        id_pregunta
    ) VALUES (
                 p_id_respuesta,
                 p_enunciado_respuesta,
                 p_respuesta_correcta,
                 p_id_pregunta
             );
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Error al crear la respuesta: ' || SQLERRM);
END add_respuesta;
/

