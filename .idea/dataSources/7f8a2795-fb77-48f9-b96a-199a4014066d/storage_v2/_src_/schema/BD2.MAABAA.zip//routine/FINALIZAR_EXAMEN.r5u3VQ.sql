create PROCEDURE finalizar_examen (
    p_id_examen IN NUMBER
) AS
BEGIN
    UPDATE EXAMEN
    SET ESTADO = 'finalizado'
    WHERE ID_EXAMEN = p_id_examen;

    COMMIT;
END;
/

