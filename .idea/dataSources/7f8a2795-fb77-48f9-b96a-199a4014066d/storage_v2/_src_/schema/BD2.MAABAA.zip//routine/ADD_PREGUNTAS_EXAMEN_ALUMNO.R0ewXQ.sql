create PROCEDURE add_preguntas_examen_alumno(
    p_id_examen_alumno IN examen_alumno.id_examen_alumno%TYPE
) IS
    v_num_preguntas_por_examen INTEGER;
    v_id_examen INTEGER;
BEGIN
    -- Obtener el id_examen asociado al examen del alumno
    SELECT id_examen INTO v_id_examen
    FROM examen_alumno
    WHERE id_examen_alumno = p_id_examen_alumno;

    -- Obtener el número de preguntas por examen asociadas al examen
    SELECT num_preg_por_examen INTO v_num_preguntas_por_examen
    FROM examen
    WHERE id_examen = v_id_examen;

    -- Insertar preguntas aleatorias asociadas al examen del alumno
    FOR preg IN (
        SELECT pe.pregunta_id_pregunta
        FROM preguntas_examen pe
        WHERE pe.examen_id_examen = v_id_examen
        ORDER BY DBMS_RANDOM.VALUE
        ) LOOP
            EXIT WHEN v_num_preguntas_por_examen = 0;

            -- Insertar la pregunta en preguntas_examen_alumno
            BEGIN
                INSERT INTO preguntas_examen_alumno (id_examen_alumno, id_pregunta)
                VALUES (p_id_examen_alumno, preg.pregunta_id_pregunta);
            EXCEPTION
                WHEN DUP_VAL_ON_INDEX THEN
                    NULL; -- Ignorar la inserción si la pregunta ya está asignada
            END;

            -- Decrementar el número de preguntas por examen restantes
            v_num_preguntas_por_examen := v_num_preguntas_por_examen - 1;
        END LOOP;

    IF v_num_preguntas_por_examen = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Todas las preguntas fueron asignadas correctamente.');
    ELSE
        DBMS_OUTPUT.PUT_LINE('No se pudieron asignar ' || v_num_preguntas_por_examen || ' preguntas debido a la falta de preguntas asociadas.');
    END IF;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('No se encontraron preguntas asociadas al examen del alumno.');
END;
/

