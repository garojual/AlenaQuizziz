create FUNCTION obtener_preguntas_respuestas(examen_id IN NUMBER)
    RETURN SYS_REFCURSOR
    IS
    c_result SYS_REFCURSOR;
BEGIN
    OPEN c_result FOR
        SELECT
            p.id_pregunta,
            p.ENUNCIADO,
            p.TIPO_PREGUNTA,
            r.id_respuesta,
            r.ENUNCIADO_RESPUESTA AS respuesta
        FROM
            pregunta p
                JOIN
            respuesta r ON p.id_pregunta = r.ID_PREGUNTA
                JOIN
            preguntas_examen pe ON p.id_pregunta = pe.pregunta_id_pregunta
        WHERE
            pe.examen_id_examen = examen_id
        ORDER BY
            p.id_pregunta, r.id_respuesta;

    RETURN c_result;
END obtener_preguntas_respuestas;
/

