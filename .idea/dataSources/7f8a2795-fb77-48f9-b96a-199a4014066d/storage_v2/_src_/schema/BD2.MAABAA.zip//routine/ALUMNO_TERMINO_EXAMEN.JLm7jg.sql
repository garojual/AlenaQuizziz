create FUNCTION alumno_termino_examen(
    p_id_alumno IN examen_alumno.id_estudiante%TYPE,
    p_id_examen IN examen_alumno.id_examen%TYPE
) RETURN BOOLEAN IS
    v_fecha_fin examen_alumno.tiempo_final%TYPE;
BEGIN
    SELECT tiempo_final
    INTO v_fecha_fin
    FROM examen_alumno
    WHERE id_estudiante = p_id_alumno AND id_examen = p_id_examen;

    IF v_fecha_fin IS NOT NULL THEN
        RETURN TRUE;
    ELSE
        RETURN FALSE;
    END IF;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN FALSE; -- No se encontró el registro, el alumno no ha tomado el examen
END;
/

