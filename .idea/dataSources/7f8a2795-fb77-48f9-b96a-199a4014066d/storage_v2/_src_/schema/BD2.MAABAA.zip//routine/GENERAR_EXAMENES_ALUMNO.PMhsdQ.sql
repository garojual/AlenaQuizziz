create PROCEDURE generar_examenes_alumno(
    p_id_curso IN INT,
    p_id_examen IN INT
) AS
    v_new_id_examen_alumno examen_alumno.id_examen_alumno%TYPE;
BEGIN
    -- Obtener el máximo ID de examen alumno actual y sumarle uno para generar el nuevo ID
    SELECT NVL(MAX(id_examen_alumno), 0) + 1 INTO v_new_id_examen_alumno FROM examen_alumno;

    -- Insertar registros en la tabla examen_alumno para cada estudiante del curso
    FOR estudiante_rec IN (
        SELECT e.id_estudiante
        FROM alumno e
                 JOIN grupo_estudiante ge ON e.id_estudiante = ge.alumno_id_estudiante
                 JOIN grupo g ON ge.grupo_id_grupo = g.id_grupo
        WHERE g.CURSO_ID_CURSO = p_id_curso
        ) LOOP
            -- Insertar el nuevo registro en la tabla examen_alumno
            INSERT INTO examen_alumno (
                id_examen_alumno,
                id_examen,
                id_estudiante
            ) VALUES (
                         v_new_id_examen_alumno,
                         p_id_examen,
                         estudiante_rec.id_estudiante
                     );

            -- Incrementar el ID de examen alumno para el próximo estudiante
            v_new_id_examen_alumno := v_new_id_examen_alumno + 1;
        END LOOP;

    -- Confirmar la transacción
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        -- En caso de error, revertir la transacción
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Error al generar los exámenes para el curso ' || p_id_curso || ': ' || SQLERRM);
END generar_examenes_alumno;
/

