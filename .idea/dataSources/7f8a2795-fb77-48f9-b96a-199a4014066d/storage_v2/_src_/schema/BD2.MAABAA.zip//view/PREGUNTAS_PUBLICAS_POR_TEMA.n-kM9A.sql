create view PREGUNTAS_PUBLICAS_POR_TEMA as
SELECT
    t.nombre_tema,
    t.ID_TEMA,
    p.id_pregunta,
    p.enunciado,
    p.tipo_pregunta
FROM pregunta p
         JOIN tema t ON p.tema_id_tema = t.id_tema
WHERE p.is_publica = 1
/

