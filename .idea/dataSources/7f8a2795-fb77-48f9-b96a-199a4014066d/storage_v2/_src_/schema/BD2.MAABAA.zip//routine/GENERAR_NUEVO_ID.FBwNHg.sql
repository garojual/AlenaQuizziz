create FUNCTION generar_nuevo_id(tabla IN VARCHAR2) RETURN NUMBER IS
    v_nuevo_id NUMBER;
BEGIN
    -- Obtener el máximo ID de la tabla
    EXECUTE IMMEDIATE 'SELECT MAX(id) FROM ' || tabla INTO v_nuevo_id;

    -- Incrementar el máximo ID en 1 para obtener el nuevo ID
    v_nuevo_id := v_nuevo_id + 1;

    -- Retornar el nuevo ID
    RETURN v_nuevo_id;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        -- Si no hay registros en la tabla, asignar el ID inicial como 1
        RETURN 1;
    WHEN OTHERS THEN
        -- Manejar cualquier otra excepción que pueda ocurrir
        RETURN NULL;
END generar_nuevo_id;
/

