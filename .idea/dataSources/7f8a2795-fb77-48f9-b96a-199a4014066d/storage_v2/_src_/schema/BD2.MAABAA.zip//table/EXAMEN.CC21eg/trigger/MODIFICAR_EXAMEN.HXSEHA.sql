create trigger MODIFICAR_EXAMEN
    before update
    on EXAMEN
    for each row
BEGIN
    IF :OLD.estado = 'presentado' THEN
        RAISE_APPLICATION_ERROR(-20002, 'No se puede modificar un examen que ya ha sido presentado.');
    END IF;
END;
/

