create FUNCTION get_respuestas(p_pregunta_id IN INTEGER) RETURN SYS_REFCURSOR IS
    v_cursor SYS_REFCURSOR;
BEGIN
    OPEN v_cursor FOR
        SELECT id_respuesta, enunciado_respuesta
        FROM respuesta
        WHERE id_pregunta = p_pregunta_id;
    RETURN v_cursor;
END;
/

