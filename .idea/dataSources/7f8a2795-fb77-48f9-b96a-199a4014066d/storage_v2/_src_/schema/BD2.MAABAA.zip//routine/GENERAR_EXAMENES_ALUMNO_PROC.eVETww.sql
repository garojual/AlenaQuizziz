create PROCEDURE generar_examenes_alumno_proc(
    p_id_profesor IN VARCHAR2,
    p_id_curso IN NUMBER,
    p_id_examen IN NUMBER
) IS
    v_new_id_examen_alumno INTEGER;
    estudiantes_cursor SYS_REFCURSOR;
    v_estudiante_id ALUMNO.ID_ESTUDIANTE%TYPE;
BEGIN
    -- Obtener el máximo ID de examen alumno actual y sumarle uno para generar el nuevo ID
    SELECT NVL(MAX(id_examen_alumno), 0) + 1 INTO v_new_id_examen_alumno FROM examen_alumno;

    -- Abrir el cursor de estudiantes para el profesor y curso específicos
    estudiantes_cursor := get_alumno_por_profesor_curso(p_id_profesor, p_id_curso);

    -- Insertar registros en la tabla examen_alumno para cada estudiante del curso
    LOOP
        FETCH estudiantes_cursor INTO v_estudiante_id;
        EXIT WHEN estudiantes_cursor%NOTFOUND;
         -- Depuración: imprimir el id_estudiante obtenido del cursor
        DBMS_OUTPUT.PUT_LINE('ID del estudiante: ' || v_estudiante_id);


        -- Insertar el nuevo registro en la tabla examen_alumno
        INSERT INTO examen_alumno (
            id_examen_alumno,
            id_examen,
            id_estudiante
        ) VALUES (
                     v_new_id_examen_alumno,
                     p_id_examen,
                     v_estudiante_id
                 );

        -- Incrementar el ID de examen alumno para el próximo estudiante
        v_new_id_examen_alumno := v_new_id_examen_alumno + 1;
    END LOOP;

    -- Cerrar el cursor de estudiantes
    CLOSE estudiantes_cursor;
END generar_examenes_alumno_proc;
/

