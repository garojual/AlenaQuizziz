create FUNCTION calcularDiferencia(
    p_numero_preguntas IN INTEGER,
    p_id_tema IN INTEGER
) RETURN INTEGER IS
    v_cantidad_preguntas INTEGER;
    v_diferencia INTEGER;
BEGIN
    -- Contar la cantidad de preguntas asociadas al tema
    SELECT COUNT(*)
    INTO v_cantidad_preguntas
    FROM pregunta
    WHERE tema_id_tema = p_id_tema;

    -- Calcular la diferencia entre la cantidad de preguntas disponibles y el número de preguntas deseado
    v_diferencia := v_cantidad_preguntas - p_numero_preguntas;

    RETURN v_diferencia;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Error al calcular la diferencia: ' || SQLERRM);
        RETURN -1; -- Devolver -1 en caso de error
END calcularDiferencia;
/

