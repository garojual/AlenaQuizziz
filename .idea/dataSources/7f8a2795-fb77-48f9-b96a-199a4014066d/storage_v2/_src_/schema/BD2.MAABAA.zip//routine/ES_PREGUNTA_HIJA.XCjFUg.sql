create FUNCTION es_pregunta_hija (
    p_id_pregunta IN NUMBER
) RETURN VARCHAR2 IS
    es_hija VARCHAR2(5);
BEGIN
    SELECT CASE
               WHEN id_pregunta_padre1 IS NOT NULL THEN 'TRUE'
               ELSE 'FALSE'
               END
    INTO es_hija
    FROM pregunta
    WHERE id_pregunta = p_id_pregunta;

    RETURN es_hija;
END;
/

