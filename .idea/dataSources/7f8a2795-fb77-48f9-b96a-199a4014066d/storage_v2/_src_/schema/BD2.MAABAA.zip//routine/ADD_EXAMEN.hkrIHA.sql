create FUNCTION add_examen(
    p_nombre_examen            IN examen.nombre_examen%TYPE,
    p_num_preguntas            IN examen.num_preguntas%TYPE,
    p_tiempo_inicio            IN examen.tiempo_inicio%TYPE,
    p_tiempo_fin               IN examen.tiempo_fin%TYPE,
    p_descripcion              IN examen.descripcion%TYPE,
    p_num_preg_por_examen      IN examen.num_preg_por_examen%TYPE,
    p_docente_id_docente       IN examen.docente_id_docente%TYPE,
    p_estado                   IN examen.estado%TYPE,
    p_tema_id_tema             IN examen.tema_id_tema%TYPE,
    p_categoria_id_categoria   IN examen.categoria_id_categoria%TYPE
) RETURN examen.id_examen%TYPE
    IS
    v_id_examen examen.id_examen%TYPE;
BEGIN
    SELECT MAX(ID_EXAMEN)+1 INTO v_id_examen FROM EXAMEN ;
    INSERT INTO examen (
        ID_EXAMEN,
        nombre_examen,
        num_preguntas,
        tiempo_inicio,
        tiempo_fin,
        descripcion,
        num_preg_por_examen,
        docente_id_docente,
        estado,
        tema_id_tema,
        categoria_id_categoria
    ) VALUES (
                 v_id_examen,
                 p_nombre_examen,
                 p_num_preguntas,
                 p_tiempo_inicio,
                 p_tiempo_fin,
                 p_descripcion,
                 p_num_preg_por_examen,
                 p_docente_id_docente,
                 p_estado,
                 p_tema_id_tema,
                 p_categoria_id_categoria
             )
    RETURNING id_examen INTO v_id_examen;

    RETURN v_id_examen;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Error al crear el examen: ' || SQLERRM);
        RETURN NULL;
END add_examen;
/

