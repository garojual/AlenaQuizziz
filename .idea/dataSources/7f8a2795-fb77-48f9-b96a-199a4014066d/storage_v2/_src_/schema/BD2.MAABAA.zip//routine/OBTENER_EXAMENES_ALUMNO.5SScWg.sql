create FUNCTION obtener_examenes_alumno(p_id_examen IN examen_alumno.id_examen_alumno%TYPE)
    RETURN SYS_REFCURSOR
    IS
    examenes_cursor SYS_REFCURSOR;
BEGIN
    OPEN examenes_cursor FOR
        SELECT id_examen
        FROM examen_alumno
        WHERE id_examen = p_id_examen;

    RETURN examenes_cursor;
END;
/

