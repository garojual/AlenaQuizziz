create view VISTA_ESTUDIANTES_CURSOS as
SELECT
    a.id_estudiante,
    a.nombre_estudiante,
    c.nombre_curso
FROM
    alumno a
        JOIN grupo_estudiante ge ON a.id_estudiante = ge.alumno_id_estudiante
        JOIN grupo g ON ge.grupo_id_grupo = g.id_grupo
        JOIN curso c ON g.curso_id_curso = c.id_curso
/

