create FUNCTION get_respuestas_por_pregunta(
    p_id_pregunta IN respuesta.id_pregunta%TYPE
) RETURN SYS_REFCURSOR IS
    v_respuestas SYS_REFCURSOR;
BEGIN
    OPEN v_respuestas FOR
        SELECT id_respuesta, id_pregunta, enunciado_respuesta, respuesta_correcta
        FROM respuesta
        WHERE id_pregunta = p_id_pregunta;

    RETURN v_respuestas;
END;
/

