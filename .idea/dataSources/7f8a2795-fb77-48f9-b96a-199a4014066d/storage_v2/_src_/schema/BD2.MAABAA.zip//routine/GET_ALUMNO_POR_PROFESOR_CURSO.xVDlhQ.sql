create FUNCTION get_alumno_por_profesor_curso(
    p_id_profesor IN INT,
    p_id_curso IN INT
) RETURN SYS_REFCURSOR AS
    estudiantes_cursor SYS_REFCURSOR;
BEGIN
    OPEN estudiantes_cursor FOR
        SELECT e.id_estudiante, e.NOMBRE_ESTUDIANTE
        FROM ALUMNO e
                 JOIN grupo_estudiante ge ON e.id_estudiante = ge.ALUMNO_ID_ESTUDIANTE
                 JOIN grupo g ON ge.GRUPO_ID_GRUPO = g.id_grupo
        WHERE g.DOCENTE_ID_DOCENTE = p_id_profesor
          AND g.CURSO_ID_CURSO = p_id_curso;
    RETURN estudiantes_cursor;
END;
/

